package com.tuglular.aircondition;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ACControllerTest {

	private ACController accontroller;

	@BeforeEach                                         
	public void setUp() throws Exception {
		accontroller = new ACController();
	}

	// Positive Tests
	
	@Test                                               
	public void test_GivenOff_WhenPowerBut_ThenFanOnly() {
		accontroller.setState("Off");
		accontroller.powerButton();
		assertEquals("FanOnly", accontroller.getState().toString());          
	}

	@Test                                               
	public void test_GivenFanOnly_WhenACBut_ThenAC() {
		accontroller.setState("FanOnly");
		accontroller.acButton();
		assertEquals("AC", accontroller.getState().toString());          
	}

	@Test                                               
	public void test_GivenFanOnly_WhenPowerBut_ThenOff() {
		accontroller.setState("FanOnly");
		accontroller.powerButton();
		assertEquals("Off", accontroller.getState().toString());          
	}
	
	@Test                                               
	public void test_GivenAC_WhenACBut_ThenFanOnly() {
		accontroller.setState("AC");
		accontroller.acButton();
		assertEquals("FanOnly", accontroller.getState().toString());          
	}

	@Test                                               
	public void test_GivenAC_WhenPowerBut_ThenOff() {
		accontroller.setState("AC");
		accontroller.powerButton();
		assertEquals("Off", accontroller.getState().toString());          
	}

	// Negative Test
	
	@Test                                               
	public void test_GivenOff_WhenACBut_ThenOff() {
		accontroller.setState("Off");
		accontroller.acButton();
		assertEquals("Off", accontroller.getState().toString());          
	}
	
}
