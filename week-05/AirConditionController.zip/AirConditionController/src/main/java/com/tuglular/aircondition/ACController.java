package com.tuglular.aircondition;

import com.tuglular.aircondition.ACController.StateMachine.State;

public class ACController {
	
	StateMachine stateMachine;

	ACController() {
		stateMachine = new StateMachine(this);
	}

	// Action methods
	private void startCondenser() {
		// To be replaced with appropriate code
		System.out.println("startCondenser executed");
	}
	private void stopCondenser() {
		// To be replaced with appropriate code
		System.out.println("stopCondenser executed");
	}
	private void startFan() {
		// To be replaced with appropriate code
		System.out.println("startFan executed");
	}
	private void stopFan() {
		// To be replaced with appropriate code
		System.out.println("stopFan executed");
	}    

	// Events delegated to StateMachine
	public void powerButton() {
		stateMachine.powerButton();
	}
	public void acButton() {
		stateMachine.acButton();
	}

	public String getState() {
		return stateMachine.state.toString();
	}
	
	// Use with caution
	// 1) String state should match Enum state
	// 2) Directly setting a state may leave some properties in invalid values for that state
	public void setState(String setState) {
		stateMachine.state = State.valueOf(setState);
	}
	
	static class StateMachine {
		ACController context;
		State state;

		StateMachine(ACController context) {
			this.context = context;
			state = State.Off; // default
		}

		private void powerButton() {
			state.process(this, Event.PowerBut);
		}
		private void acButton() {
			state.process(this, Event.ACBut);
		}

		// All events
		enum Event { PowerBut, ACBut };

		// All states
		enum State {
			Off {
				void entry(StateMachine sm) {
				}
				void exit(StateMachine sm) {
				}
				void process(StateMachine sm, Event event) {
					switch(event) {
					case ACBut:
						break;
					case PowerBut:
						this.exit(sm);
						sm.context.startFan();
						sm.state = FanOnly;
						sm.state.entry(sm);
					}
				}
			},
			FanOnly {
				void entry(StateMachine sm) {
				}
				void exit(StateMachine sm) {
				}
				void process(StateMachine sm, Event event) {
					switch(event) {
					case ACBut:
						this.exit(sm);
						sm.state = AC;
						sm.state.entry(sm);
						break;
					case PowerBut:
						this.exit(sm);
						sm.context.stopFan();
						sm.state = Off;
						sm.state.entry(sm);
					}
				}
			},
			AC {
				void entry(StateMachine sm) {
					sm.context.startCondenser();
				}
				void exit(StateMachine sm) {
					sm.context.stopCondenser();
				}
				void process(StateMachine sm, Event event) {
					switch(event) {
					case ACBut:
						this.exit(sm);
						sm.state = FanOnly;
						sm.state.entry(sm);
						break;
					case PowerBut:
						this.exit(sm);
						sm.context.stopFan();
						sm.state = Off;
						sm.state.entry(sm);
					}
				}
			};

			abstract void process(StateMachine sm, Event event);
			abstract void entry(StateMachine sm);
			abstract void exit(StateMachine sm);
		}
	}
}
