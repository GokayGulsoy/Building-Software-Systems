package com.tuglular.aircondition;

public class ACControllerDemo {

	public static void main(String[] args) {
		
		ACController accontroller = new ACController();
		
		newExecutionStarts();
		accontroller.powerButton();
		accontroller.acButton();
		accontroller.acButton();
		accontroller.powerButton();
	
		newExecutionStarts();
		accontroller.powerButton();
		accontroller.acButton();
		accontroller.powerButton();

		newExecutionStarts();
		accontroller.powerButton();
		accontroller.powerButton();
	}
	
	public static void newExecutionStarts() {
		System.out.println("");
		System.out.println("New execution starts");
	}
}
